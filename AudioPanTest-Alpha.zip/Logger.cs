using System;
using System.Diagnostics;
using System.IO;

namespace AudioPanUI;

internal static class Logger
{
    private static readonly object _lock = new();

    private static string LogPath
    {
        get
        {
            string dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "AudioPanUI");
            Directory.CreateDirectory(dir);
            return Path.Combine(dir, "log.txt");
        }
    }

    public static void Log(string message)
    {
        try
        {
            lock (_lock)
            {
                File.AppendAllText(LogPath,
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}] {message}{Environment.NewLine}");
            }
        }
        catch { /* never throw from logger */ }
    }

    public static void Log(Exception ex, string context)
    {
        Log($"{context}: {ex}");
    }
}
