using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using System.Windows.Media;
using System.Windows.Interop;

namespace AudioPanUI;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        // Max stability: avoid GPU/USB-C driver glitches from WPF hardware acceleration.
        RenderOptions.ProcessRenderMode = RenderMode.SoftwareOnly;

        // Global exception logging so "crash with no error" becomes actionable.
        DispatcherUnhandledException += (_, exArgs) =>
        {
            Logger.Log(exArgs.Exception, "DispatcherUnhandledException");
            MessageBox.Show(exArgs.Exception.ToString(), "AudioPanUI crash (UI thread)");
            exArgs.Handled = true;
        };

        AppDomain.CurrentDomain.UnhandledException += (_, exArgs) =>
        {
            if (exArgs.ExceptionObject is Exception ex)
                Logger.Log(ex, "UnhandledException");
            else
                Logger.Log("UnhandledException: " + exArgs.ExceptionObject);
        };

        TaskScheduler.UnobservedTaskException += (_, exArgs) =>
        {
            Logger.Log(exArgs.Exception, "UnobservedTaskException");
            exArgs.SetObserved();
        };

        base.OnStartup(e);

        var win = new MainWindow();
        MainWindow = win;
        win.Show();
    }
}
