# AudioPanUI — Alpha Versions

**AudioPanUI** is a lightweight Windows utility that automatically pans application audio left or right based on the position of the active window on your screen.

Move a window to the left → audio shifts left.
Move it right → audio shifts right.
Center the window → audio recenters smoothly.

The goal is subtle, natural spatial awareness across single or multiple monitors without manual mixing.

---

## Status

**Version:** v0.2.0 Alpha
**Stability:** Core engine stable, GPU-safe rendering enabled
**Scope:** Early public preview for feedback

This build is intended for real-world testing, not final release.

---

## Features

* Real-time stereo panning driven by **active window position**
* Smooth **equal-power panning** with motion smoothing
* Independent handling of **Windows audio sessions**
* **System tray mode** with background operation
* **Single global hotkey**:

  * **Ctrl + Alt + P** → Toggle panning

    * Turning OFF automatically **recenters audio**
    * Tray notification shows current state
* **GPU-safe software rendering** for maximum stability on external monitors
* **Single-file executable** distribution (no install required)

---

## What’s intentionally NOT in alpha

To keep behavior clean and predictable:

* No dead-zone snapping
* No complex configuration UI
* No per-app exclusions (yet)
* No custom hotkey editor

These may arrive in later versions based on feedback.

---

## Running the app

1. Launch **AudioPanUI.exe**
2. The app can minimize to the **system tray**
3. Use **Ctrl + Alt + P** anytime to toggle panning on/off

No installation or administrator rights required.

---

## Known limitations

* Early alpha UI polish is minimal
* Some background/system audio sessions may appear in logs
* Multi-monitor edge behavior may evolve with feedback

No hardware risk — the app only adjusts **software audio balance**.

---

## Feedback

This alpha exists to answer one question:

**Is this actually useful in real daily use?**

If you have thoughts, bugs, or ideas, share them where you found this build.

Even short feedback helps shape the next version.

---

## License / distribution

This alpha is shared **free for testing**.
No guarantees, no warranty — just an experimental utility being explored.
