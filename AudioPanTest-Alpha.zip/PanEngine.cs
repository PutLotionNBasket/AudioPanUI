using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

namespace AudioPanUI;

public sealed class PanEngine
{
    private PanSettings _settings;
    private Thread _thread;
    private volatile bool _stop;

    // UI callback
    public Action<Snapshot> OnSnapshot;

    private sealed class State
    {
        public float T = 0.5f;
        public float TTarget = 0.5f;
        public float LastL = -1f;
        public float LastR = -1f;
        public long LastSeen = 0;
    }

    private readonly Dictionary<int, State> _states = new();
    private readonly HashSet<int> _touched = new();

    private readonly Dictionary<int, bool> _panEnabledByPid = new();
    private readonly object _panEnabledLock = new();

    private readonly HashSet<int> _pendingNeutralize = new();
    private readonly object _pendingNeutralizeLock = new();

private const float Center = 0.70710677f;

    public PanEngine(PanSettings initial) => _settings = initial;

    public void SetPidPanEnabled(int pid, bool enabled)
    {
        lock (_panEnabledLock)
        {
            _panEnabledByPid[pid] = enabled;
        }

        if (!enabled)
        {
            // Do NOT call COM audio APIs on the UI thread.
            // Queue a neutralize that the engine thread will apply on its next tick.
            lock (_pendingNeutralizeLock)
            {
                _pendingNeutralize.Add(pid);
            }

            lock (_states)
            {
                if (_states.TryGetValue(pid, out var st))
                {
                    st.LastL = Center;
                    st.LastR = Center;
                }
            }

            lock (_touched)
            {
                _touched.Remove(pid);
            }
        }
    }

    private bool IsPidPanEnabled(int pid)
    {
        lock (_panEnabledLock)
        {
            return !_panEnabledByPid.TryGetValue(pid, out bool enabled) || enabled;
        }
    }


    private void DrainPendingNeutralize()
    {
        int[] pids;
        lock (_pendingNeutralizeLock)
        {
            if (_pendingNeutralize.Count == 0) return;
            pids = new int[_pendingNeutralize.Count];
            _pendingNeutralize.CopyTo(pids);
            _pendingNeutralize.Clear();
        }

        foreach (int pid in pids)
        {
            try
            {
                SetPanForPid(pid, Center, Center);
            }
            catch
            {
                // Ignore COM errors; session may have ended.
            }
        }
    }


public void UpdateSettings(PanSettings s) => _settings = s;

    public void Start()
    {
        _stop = false;
        _thread = new Thread(Worker) { IsBackground = true };
        _thread.SetApartmentState(ApartmentState.STA);
        _thread.Start();
    }

    public void Stop()
    {
        _stop = true;
        if (_thread != null && _thread.IsAlive) _thread.Join();
        _thread = null;

        // Don't call COM audio APIs on the UI thread.
        // Recenter on a lightweight STA background thread.
        var t = new Thread(() =>
        {
            CoInitializeEx(IntPtr.Zero, 2); // STA
            try { RecenterAllTouched(); }
            catch { }
            finally { CoUninitialize(); }
        }) { IsBackground = true };
        t.SetApartmentState(ApartmentState.STA);
        t.Start();
    }

    public void RecenterNow()
    {
        // Fire-and-forget recenter on an STA thread so UI never blocks.
        var t = new Thread(() =>
        {
            CoInitializeEx(IntPtr.Zero, 2); // STA
            try { RecenterAllTouched(); }
            catch { }
            finally { CoUninitialize(); }
        }) { IsBackground = true };
        t.SetApartmentState(ApartmentState.STA);
        t.Start();
    }


    private void Worker()
    {
        CoInitializeEx(IntPtr.Zero, 2); // STA

        try
        {
            long tick = 0;

            while (!_stop)
            {
                try
                {
                tick++;

                var s = _settings;

                DrainPendingNeutralize();

                var pidToRect = BuildPidToWindowMap(out var procNameToRect);
                var audioPids = GetControllableAudioPids();

                var rows = new List<SessionRow>(audioPids.Count);

                foreach (int pid in audioPids)
                {
                    // Some apps (notably Chromium-based browsers like Edge) produce audio
                    // from a helper/sandbox process that has no top-level window. In those
                    // cases, fall back to using the best visible window for that process name.
                    Rect r;
                    if (!pidToRect.TryGetValue(pid, out r))
                    {
                        var pn = SafeProcessName(pid);
                        if (pn == "?" || !procNameToRect.TryGetValue(pn, out r))
                            continue;
                    }

                    int cx = r.Left + (r.Right - r.Left) / 2;
                    int cy = r.Top + (r.Bottom - r.Top) / 2;

                    Rect wa;
                    if (s.GlobalAcrossMonitors)
                    {
                        if (!TryGetGlobalWorkArea(out wa))
                            continue;
                    }
                    else
                    {
                        if (!TryGetMonitorWorkAreaFromPoint(cx, cy, out wa))
                            continue;
                    }

                    int sw = wa.Right - wa.Left;
                    if (sw <= 0) continue;

                    float tRaw = Clamp01((cx - wa.Left) / (float)sw);
                    float tTarget = ApplyIntensityCurve(tRaw, s.Intensity);

                    if (!_states.TryGetValue(pid, out State st))
                    {
                        st = new State();
                        _states[pid] = st;
                    }

                    st.TTarget = tTarget;
                    st.T += (st.TTarget - st.T) * s.Smooth;
                    st.LastSeen = tick;

                    // Equal-power base
                    float theta = st.T * (float)(Math.PI / 2.0);
                    float L0 = (float)Math.Cos(theta);
                    float R0 = (float)Math.Sin(theta);

                    // Width shaping
                    if (s.Width < 0.999f)
                    {
                        L0 = L0 * s.Width + Center * (1f - s.Width);
                        R0 = R0 * s.Width + Center * (1f - s.Width);
                    }

                    // Crossfeed + normalize
                    float L = L0, Rch = R0;
                    if (s.Crossfeed > 0.0001f)
                    {
                        float L1 = L0 + s.Crossfeed * R0;
                        float R1 = R0 + s.Crossfeed * L0;
                        float norm = (float)Math.Sqrt(L1 * L1 + R1 * R1);
                        L = L1 / norm;
                        Rch = R1 / norm;
                    }

                    bool changed = Math.Abs(L - st.LastL) > s.Deadband || Math.Abs(Rch - st.LastR) > s.Deadband;

	                    if (changed)
	                    {
	                        if (IsPidPanEnabled(pid))
	                        {
	                            if (SetPanForPid(pid, L, Rch))
	                            {
	                                st.LastL = L;
	                                st.LastR = Rch;
	                                _touched.Add(pid);
	                            }
	                        }
	                    }

                    rows.Add(new SessionRow
                    {
                        Pid = pid,
                        Process = SafeProcessName(pid),
                        T = st.T,
                        L = L,
                        R = Rch,
                        WindowInfo = $"x={r.Left}, y={r.Top}, w={r.Right - r.Left}, h={r.Bottom - r.Top}"
                    });
                }

                // Forget stale
                const long forgetAfterTicks = 300;
                List<int> remove = null;
                foreach (var kv in _states)
                {
                    if (tick - kv.Value.LastSeen > forgetAfterTicks)
                    {
                        remove ??= new List<int>();
                        remove.Add(kv.Key);
                    }
                }
                if (remove != null)
                    foreach (int pid in remove) _states.Remove(pid);

                if (OnSnapshot != null)
                    OnSnapshot(new Snapshot { Sessions = rows.ToArray() });

                Thread.Sleep(s.TickMs);
                }
                catch (Exception ex)
                {
                    Logger.Log(ex, "PanEngine.Worker loop");
                    Thread.Sleep(250);
                }
            }
        }
        finally
        {
            CoUninitialize();
        }
    }

    private static string SafeProcessName(int pid)
    {
        try { return Process.GetProcessById(pid).ProcessName; }
        catch { return "?"; }
    }

    private void RecenterAllTouched()
    {
        const float c = Center;
        int[] pids = new int[_touched.Count];
        _touched.CopyTo(pids);
        foreach (int pid in pids)
        {
            try { SetPanForPid(pid, c, c); } catch { }
        }
    }

    private static float ApplyIntensityCurve(float t, float intensity)
    {
        if (intensity <= 1.001f) return t;

        float centered = t - 0.5f;
        float sign = centered < 0 ? -1f : 1f;
        float mag = Math.Abs(centered) * 2f;

        float mag2 = (float)Math.Pow(mag, 1f / intensity);
        float outT = 0.5f + sign * (mag2 * 0.5f);
        return Clamp01(outT);
    }

    private static float Clamp01(float v) => v < 0 ? 0 : (v > 1 ? 1 : v);

    private static float ClampVol(float v)
    {
        if (float.IsNaN(v) || float.IsInfinity(v)) return Center;
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    // ------------------ Window mapping ------------------

    private static Dictionary<int, Rect> BuildPidToWindowMap(out Dictionary<string, Rect> procNameToRect)
    {
        var best = new Dictionary<int, Rect>();
        var procNameMap = new Dictionary<string, Rect>(StringComparer.OrdinalIgnoreCase);
        IntPtr shell = GetShellWindow();

        EnumWindows((hWnd, lParam) =>
        {
            if (hWnd == shell) return true;
            if (!IsWindowVisible(hWnd)) return true;

            if (!GetWindowRect(hWnd, out Rect r)) return true;

            int w = r.Right - r.Left;
            int h = r.Bottom - r.Top;
            if (w < 200 || h < 150) return true;

            GetWindowThreadProcessId(hWnd, out uint upid);
            int pid = unchecked((int)upid);
            if (pid <= 0) return true;

            long area = (long)w * h;

            if (!best.TryGetValue(pid, out Rect current))
                best[pid] = r;
            else
            {
                long cArea = (long)(current.Right - current.Left) * (current.Bottom - current.Top);
                if (area > cArea) best[pid] = r;
            }

            // Also keep a best-guess window per process name (handles multi-process apps like Edge/Chrome).
            string pn;
            try { pn = Process.GetProcessById(pid).ProcessName; }
            catch { pn = "?"; }

            if (pn != "?")
            {
                if (!procNameMap.TryGetValue(pn, out Rect pr))
                    procNameMap[pn] = r;
                else
                {
                    long pArea = (long)(pr.Right - pr.Left) * (pr.Bottom - pr.Top);
                    if (area > pArea) procNameMap[pn] = r;
                }
            }
            return true;

        }, IntPtr.Zero);

        procNameToRect = procNameMap;

        return best;
    }

    private static bool TryGetMonitorWorkAreaFromPoint(int x, int y, out Rect workArea)
    {
        workArea = new Rect();
        POINT pt = new POINT { X = x, Y = y };
        IntPtr hMon = MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST);
        if (hMon == IntPtr.Zero) return false;

        MONITORINFO mi = new MONITORINFO();
        mi.cbSize = Marshal.SizeOf(typeof(MONITORINFO));
        if (!GetMonitorInfo(hMon, ref mi)) return false;

        workArea = mi.rcWork;
        return true;
    }


    private static bool TryGetGlobalWorkArea(out Rect workArea)
    {
        // Union of rcWork across all monitors (taskbar-aware per monitor).
        bool any = false;
        int left = 0, top = 0, right = 0, bottom = 0;

        EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, (hMon, hdc, lprc, lParam) =>
        {
            MONITORINFO mi = new MONITORINFO();
            mi.cbSize = Marshal.SizeOf(typeof(MONITORINFO));
            if (GetMonitorInfo(hMon, ref mi))
            {
                Rect r = mi.rcWork;
                if (!any)
                {
                    left = r.Left; top = r.Top; right = r.Right; bottom = r.Bottom;
                    any = true;
                }
                else
                {
                    if (r.Left < left) left = r.Left;
                    if (r.Top < top) top = r.Top;
                    if (r.Right > right) right = r.Right;
                    if (r.Bottom > bottom) bottom = r.Bottom;
                }
            }
            return true;
        }, IntPtr.Zero);

        if (any)
        {
            workArea = new Rect { Left = left, Top = top, Right = right, Bottom = bottom };
            return (workArea.Right - workArea.Left) > 0;
        }

        // Fallback to virtual screen metrics
        int vx = GetSystemMetrics(SM_XVIRTUALSCREEN);
        int vy = GetSystemMetrics(SM_YVIRTUALSCREEN);
        int vw = GetSystemMetrics(SM_CXVIRTUALSCREEN);
        int vh = GetSystemMetrics(SM_CYVIRTUALSCREEN);

        if (vw <= 0 || vh <= 0)
        {
            workArea = new Rect();
            return false;
        }

        workArea = new Rect { Left = vx, Top = vy, Right = vx + vw, Bottom = vy + vh };
        return true;
    }

    // ------------------ Core Audio ------------------

    private static List<int> GetControllableAudioPids()
    {
        var mgr = GetSessionManager();
        Marshal.ThrowExceptionForHR(mgr.GetSessionEnumerator(out IAudioSessionEnumerator sessions));
        Marshal.ThrowExceptionForHR(sessions.GetCount(out int count));

        var set = new HashSet<int>();

        for (int i = 0; i < count; i++)
        {
            Marshal.ThrowExceptionForHR(sessions.GetSession(i, out IAudioSessionControl ctl));
            var ctl2 = (IAudioSessionControl2)ctl;

            Marshal.ThrowExceptionForHR(ctl2.GetProcessId(out uint spid));
            int pid = (int)spid;
            if (pid <= 0) continue;

            var ch = ctl as IChannelAudioVolume;
            if (ch == null) continue;

            Marshal.ThrowExceptionForHR(ch.GetChannelCount(out uint chCount));
            if (chCount >= 2) set.Add(pid);
        }

        return new List<int>(set);
    }

    private static bool SetPanForPid(int pid, float left, float right)
    {
        
        left = ClampVol(left);
        right = ClampVol(right);
var mgr = GetSessionManager();
        Marshal.ThrowExceptionForHR(mgr.GetSessionEnumerator(out IAudioSessionEnumerator sessions));
        Marshal.ThrowExceptionForHR(sessions.GetCount(out int count));

        bool did = false;

        for (int i = 0; i < count; i++)
        {
            Marshal.ThrowExceptionForHR(sessions.GetSession(i, out IAudioSessionControl ctl));
            var ctl2 = (IAudioSessionControl2)ctl;

            Marshal.ThrowExceptionForHR(ctl2.GetProcessId(out uint spid));
            if ((int)spid != pid) continue;

            var ch = ctl as IChannelAudioVolume;
            if (ch == null) continue;

            Marshal.ThrowExceptionForHR(ch.GetChannelCount(out uint chCount));
            if (chCount >= 2)
            {
                try
                {
                    Marshal.ThrowExceptionForHR(ch.SetChannelVolume(0, left, Guid.Empty));
                    Marshal.ThrowExceptionForHR(ch.SetChannelVolume(1, right, Guid.Empty));
                    did = true;
                }
                catch (System.ArgumentException ex)
                {
                    // Some sessions/drivers return E_INVALIDARG sporadically; log and skip this iteration.
                    Logger.Log(ex, $"SetChannelVolume E_INVALIDARG pid={pid} L={left} R={right}");
                }
            }
        }

        return did;
    }

    private static IAudioSessionManager2 GetSessionManager()
    {
        IMMDeviceEnumerator enumerator = (IMMDeviceEnumerator)new MMDeviceEnumerator();
        Marshal.ThrowExceptionForHR(enumerator.GetDefaultAudioEndpoint(EDataFlow.eRender, ERole.eMultimedia, out IMMDevice device));

        Guid iid = typeof(IAudioSessionManager2).GUID;
        Marshal.ThrowExceptionForHR(device.Activate(ref iid, CLSCTX.CLSCTX_ALL, IntPtr.Zero, out IntPtr pMgr));

        IAudioSessionManager2 mgr = (IAudioSessionManager2)Marshal.GetObjectForIUnknown(pMgr);
        Marshal.Release(pMgr);
        return mgr;
    }

    // ------------------ P/Invokes ------------------

    private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    private delegate bool MonitorEnumProc(IntPtr hMon, IntPtr hdc, IntPtr lprcMonitor, IntPtr dwData);

    [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool GetWindowRect(IntPtr hWnd, out Rect lpRect);
    [DllImport("user32.dll", SetLastError = true)] private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
    [DllImport("user32.dll")] private static extern IntPtr GetShellWindow();

    private const uint MONITOR_DEFAULTTONEAREST = 2;
    [DllImport("user32.dll")] private static extern IntPtr MonitorFromPoint(POINT pt, uint dwFlags);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFO lpmi);
    [DllImport("user32.dll")] private static extern bool EnumDisplayMonitors(IntPtr hdc, IntPtr lprcClip, MonitorEnumProc lpfnEnum, IntPtr dwData);
    [DllImport("user32.dll")] private static extern int GetSystemMetrics(int nIndex);

    private const int SM_XVIRTUALSCREEN = 76;
    private const int SM_YVIRTUALSCREEN = 77;
    private const int SM_CXVIRTUALSCREEN = 78;
    private const int SM_CYVIRTUALSCREEN = 79;


    [DllImport("ole32.dll")] private static extern int CoInitializeEx(IntPtr pvReserved, uint dwCoInit);
    [DllImport("ole32.dll")] private static extern void CoUninitialize();

    [StructLayout(LayoutKind.Sequential)]
    private struct POINT { public int X; public int Y; }

    [StructLayout(LayoutKind.Sequential)]
    private struct Rect { public int Left, Top, Right, Bottom; }

    [StructLayout(LayoutKind.Sequential)]
    private struct MONITORINFO
    {
        public int cbSize;
        public Rect rcMonitor;
        public Rect rcWork;
        public uint dwFlags;
    }

    private enum EDataFlow { eRender = 0 }
    private enum ERole { eMultimedia = 1 }

    [Flags]
    private enum CLSCTX : uint
    {
        CLSCTX_INPROC_SERVER = 0x1,
        CLSCTX_INPROC_HANDLER = 0x2,
        CLSCTX_LOCAL_SERVER = 0x4,
        CLSCTX_ALL = CLSCTX_INPROC_SERVER | CLSCTX_INPROC_HANDLER | CLSCTX_LOCAL_SERVER
    }

    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    private class MMDeviceEnumerator { }

    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"),
     InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDeviceEnumerator
    {
        int NotImpl1();
        [PreserveSig] int GetDefaultAudioEndpoint(EDataFlow dataFlow, ERole role, out IMMDevice device);
    }

    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"),
     InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDevice
    {
        [PreserveSig] int Activate(ref Guid iid, CLSCTX ctx, IntPtr p, out IntPtr ppInterface);
    }

    [ComImport, Guid("77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F"),
     InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioSessionManager2
    {
        int NotImpl1();
        int NotImpl2();
        [PreserveSig] int GetSessionEnumerator(out IAudioSessionEnumerator sessions);
    }

    [ComImport, Guid("E2F5BB11-0570-40CA-ACDD-3AA01277DEE8"),
     InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioSessionEnumerator
    {
        [PreserveSig] int GetCount(out int count);
        [PreserveSig] int GetSession(int index, out IAudioSessionControl ctl);
    }

    [ComImport, Guid("F4B1A599-7266-4319-A8CA-E70ACB11E8CD"),
     InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioSessionControl { }

    [ComImport, Guid("bfb7ff88-7239-4fc9-8fa2-07c950be9c6d"),
     InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioSessionControl2
    {
        [PreserveSig] int GetState(out int state);
        [PreserveSig] int GetDisplayName([MarshalAs(UnmanagedType.LPWStr)] out string name);
        [PreserveSig] int SetDisplayName([MarshalAs(UnmanagedType.LPWStr)] string name, Guid ctx);
        [PreserveSig] int GetIconPath([MarshalAs(UnmanagedType.LPWStr)] out string path);
        [PreserveSig] int SetIconPath([MarshalAs(UnmanagedType.LPWStr)] string path, Guid ctx);
        [PreserveSig] int GetGroupingParam(out Guid guid);
        [PreserveSig] int SetGroupingParam(Guid guid, Guid ctx);
        [PreserveSig] int RegisterAudioSessionNotification(IntPtr p);
        [PreserveSig] int UnregisterAudioSessionNotification(IntPtr p);

        [PreserveSig] int GetSessionIdentifier([MarshalAs(UnmanagedType.LPWStr)] out string id);
        [PreserveSig] int GetSessionInstanceIdentifier([MarshalAs(UnmanagedType.LPWStr)] out string id);
        [PreserveSig] int GetProcessId(out uint pid);
        [PreserveSig] int IsSystemSoundsSession();
        [PreserveSig] int SetDuckingPreference(bool optOut);
    }

    [ComImport, Guid("1C158861-B533-4B30-B1CF-E853E51C59B8"),
     InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IChannelAudioVolume
    {
        [PreserveSig] int GetChannelCount(out uint count);
        [PreserveSig] int SetChannelVolume(uint index, float level, Guid ctx);
    }
}