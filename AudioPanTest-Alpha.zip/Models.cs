using System;
using System.ComponentModel;

namespace AudioPanUI;

public enum OutputMode
{
    Headphones,
    Speakers
}

public sealed class PanSettings
{
    public OutputMode Mode;
    public int TickMs;
    public float Smooth;
    public float Deadband;
    public float Width;
    public float Crossfeed;
    public float Intensity;

    // Multi-monitor behavior:
    // false = pan based on the window's *current monitor* work area (existing behavior)
    // true  = pan based on the union of all monitor work areas (global)
    public bool GlobalAcrossMonitors;
}

public sealed class SessionRow : INotifyPropertyChanged
{
    private bool _panEnabled = true;
    private string _process = "";
    private float _t;
    private float _l;
    private float _r;
    private string _windowInfo = "";

    public int Pid { get; init; }

    public bool PanEnabled
    {
        get => _panEnabled;
        set
        {
            if (_panEnabled == value) return;
            _panEnabled = value;
            OnPropertyChanged(nameof(PanEnabled));
        }
    }

    public string Process
    {
        get => _process;
        set
        {
            if (_process == value) return;
            _process = value;
            OnPropertyChanged(nameof(Process));
        }
    }

    public float T
    {
        get => _t;
        set
        {
            if (Math.Abs(_t - value) < 0.0001f) return;
            _t = value;
            OnPropertyChanged(nameof(T));
        }
    }

    public float L
    {
        get => _l;
        set
        {
            if (Math.Abs(_l - value) < 0.0001f) return;
            _l = value;
            OnPropertyChanged(nameof(L));
        }
    }

    public float R
    {
        get => _r;
        set
        {
            if (Math.Abs(_r - value) < 0.0001f) return;
            _r = value;
            OnPropertyChanged(nameof(R));
        }
    }

    public string WindowInfo
    {
        get => _windowInfo;
        set
        {
            if (_windowInfo == value) return;
            _windowInfo = value;
            OnPropertyChanged(nameof(WindowInfo));
        }
    }

    public event PropertyChangedEventHandler PropertyChanged;
    private void OnPropertyChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}

public sealed class Snapshot
{
    public SessionRow[] Sessions { get; set; } = Array.Empty<SessionRow>();
}
