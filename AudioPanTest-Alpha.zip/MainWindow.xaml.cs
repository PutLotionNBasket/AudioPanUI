using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using WinForms = System.Windows.Forms;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Windows.Interop;

namespace AudioPanUI;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<SessionRow> _rows = new();
    private readonly Dictionary<int, bool> _panEnabledByPid = new();
    private readonly Dictionary<int, SessionRow> _rowsByPid = new();

    // Note: Nullable reference types are disabled in the csproj.
    // Keep this field as a plain reference and use null as the stopped sentinel.
    private PanEngine _engine = null;

    // Guard: WPF fires events during InitializeComponent; don't react until Loaded.
    private bool _isLoaded = false;

    // Snapshot marshaling:
    // Never block the engine thread on the UI thread (Dispatcher.Invoke), or Stop() can deadlock
    // while the UI waits for the engine thread to join.
    private readonly object _snapshotLock = new();
    private Snapshot _latestSnapshot = null;
    private int _uiUpdateQueued = 0;
    private volatile bool _stopping = false;

    // Tray
    private WinForms.NotifyIcon _tray = null;
    private bool _exitRequested = false;
    private bool _minimizeToTray = true; // set after InitializeComponent

    
    private void ShowTrayToast(string title, string message)
    {
        try
        {
            if (_tray == null) return;
            _tray.BalloonTipTitle = title;
            _tray.BalloonTipText = message;
            _tray.ShowBalloonTip(1200);
        }
        catch { }
    }

// Global hotkeys
    private HwndSource _hwndSource = null;
    private bool _hotkeysRegistered = false;
    private const int WM_HOTKEY = 0x0312;
    private const uint MOD_ALT = 0x0001;
    private const uint MOD_CONTROL = 0x0002;
    private const int HOTKEY_ID_TOGGLE = 0xA001;
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    
    private static System.Drawing.Icon SafeAppIcon()
    {
        try
        {
            // Uses the app's embedded ApplicationIcon when present.
            var path = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
            var ico = System.Drawing.Icon.ExtractAssociatedIcon(path);
            return ico ?? System.Drawing.SystemIcons.Application;
        }
        catch
        {
            return System.Drawing.SystemIcons.Application;
        }
    }

private void QueueUiUpdate()
    {
        if (_stopping) return;
        if (Interlocked.Exchange(ref _uiUpdateQueued, 1) != 0) return;

        Dispatcher.BeginInvoke(new Action(() =>
        {
            try
            {
                if (_stopping) return;

                Snapshot snap;
                lock (_snapshotLock)
                {
                    snap = _latestSnapshot;
                    _latestSnapshot = null;
                }
                if (snap == null) return;

                // Note: we do NOT rebuild the collection every tick. That caused UI flicker
                // and made it hard to interact with per-PID toggles. Instead we update rows in place.
                var seen = new HashSet<int>();

                foreach (var s in snap.Sessions)
                {
                    seen.Add(s.Pid);

                    if (_rowsByPid.TryGetValue(s.Pid, out var row))
                    {
                        // Keep row.PanEnabled as-is (it's user-controlled), just update live fields.
                        row.Process = s.Process;
                        row.T = s.T;
                        row.L = s.L;
                        row.R = s.R;
                        row.WindowInfo = s.WindowInfo;
                    }
                    else
                    {
                        bool enabled = _panEnabledByPid.TryGetValue(s.Pid, out var e) ? e : true;

                        var newRow = new SessionRow
                        {
                            Pid = s.Pid,
                            Process = s.Process,
                            PanEnabled = enabled,
                            T = s.T,
                            L = s.L,
                            R = s.R,
                            WindowInfo = s.WindowInfo
                        };

                        _rowsByPid[s.Pid] = newRow;
                        _rows.Add(newRow);
                    }
                }

                // Remove rows that no longer exist.
                for (int i = _rows.Count - 1; i >= 0; i--)
                {
                    int pid = _rows[i].Pid;
                    if (!seen.Contains(pid))
                    {
                        _rowsByPid.Remove(pid);
                        _rows.RemoveAt(i);
                    }
                }
            }
            finally
            {
                Interlocked.Exchange(ref _uiUpdateQueued, 0);

                // If a newer snapshot arrived while we were updating, schedule one more UI pass.
                bool hasMore;
                lock (_snapshotLock)
                {
                    hasMore = _latestSnapshot != null;
                }
                if (hasMore) QueueUiUpdate();
            }
        }), DispatcherPriority.Background);
    }

    public MainWindow()
    {
        InitializeComponent();

        // Slightly widen the window for readability (alpha default)
        try { this.Width = this.Width + 50; } catch { }

        // Register global hotkeys after HWND exists.
        SourceInitialized += (_, _) => InitHotkeys();


        _minimizeToTray = MinimizeToTrayCheck?.IsChecked == true;
// DEBUG: UI heartbeat (no Visual Studio needed)
var heartbeat = new DispatcherTimer { Interval = System.TimeSpan.FromSeconds(1) };
heartbeat.Tick += (s, e) =>
{
    try
    {
        this.Title = "AudioPanUI DEBUG  " + System.DateTime.Now.ToString("HH:mm:ss");
    }
    catch { /* ignore */ }
};
heartbeat.Start();

// DEBUG: UI responsiveness watchdog (logs stalls to %LOCALAPPDATA%\AudioPanUI\log.txt)
_ = Task.Run(async () =>
{
    while (true)
    {
        try
        {
            var tcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            this.Dispatcher.BeginInvoke(new System.Action(() => tcs.TrySetResult(true)));
            var completed = await Task.WhenAny(tcs.Task, Task.Delay(2000)).ConfigureAwait(false);
            if (completed != tcs.Task)
            {
                Logger.Log("UI STALL detected: Dispatcher did not respond within 2000ms.");
            }
        }
        catch (System.Exception ex)
        {
            Logger.Log(ex, "UI watchdog");
        }

        await Task.Delay(500).ConfigureAwait(false);
    }
});


        SessionsGrid.ItemsSource = _rows;

        Loaded += (_, _) =>
        {
            _isLoaded = true;
            ApplyModeDefaults();
            RefreshLabels();
        };

        RunStatusText.Text = "Stopped";
            ShowTrayToast("AudioPanUI", "Panning OFF — centered");
        StartStopButton.Content = "Start";

        _minimizeToTray = MinimizeToTrayCheck.IsChecked == true;
        InitTray();
    }

    private void InitHotkeys()
    {
        if (_hotkeysRegistered) return;

        try
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            if (hwnd == IntPtr.Zero) return;

            _hwndSource = HwndSource.FromHwnd(hwnd);
            _hwndSource.AddHook(WndProc);

            // Ctrl+Alt+P => Toggle Start/Stop
            bool ok1 = RegisterHotKey(hwnd, HOTKEY_ID_TOGGLE, MOD_CONTROL | MOD_ALT, (uint)System.Windows.Forms.Keys.P);

            // Even if registration fails (conflict), the app should still run.
            _hotkeysRegistered = ok1;
        }
        catch
        {
            // Ignore; hotkeys are optional.
        }
    }

    private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg == WM_HOTKEY)
        {
            int id = wParam.ToInt32();
            if (id == HOTKEY_ID_TOGGLE)
            {
                handled = true;
                Dispatcher.BeginInvoke(new Action(ToggleStartStop));
            }
        }
        return IntPtr.Zero;
    }


    private void InitTray()
    {
        _tray = new WinForms.NotifyIcon
        {
            Text = "AudioPanUI",
            Icon = SafeAppIcon(),
            Visible = true
        };

        var menu = new WinForms.ContextMenuStrip();

        var openItem = new WinForms.ToolStripMenuItem("Open");
        openItem.Click += (_, _) => Dispatcher.BeginInvoke(new Action(ShowFromTray));
        menu.Items.Add(openItem);

        menu.Items.Add(new WinForms.ToolStripSeparator());

        var toggleItem = new WinForms.ToolStripMenuItem("Start / Stop");
        toggleItem.Click += (_, _) => Dispatcher.BeginInvoke(new Action(ToggleStartStop));
        menu.Items.Add(toggleItem);

        var recenterItem = new WinForms.ToolStripMenuItem("Recenter now");
        recenterItem.Click += (_, _) => Dispatcher.BeginInvoke(new Action(RecenterNow));
        menu.Items.Add(recenterItem);

        menu.Items.Add(new WinForms.ToolStripSeparator());

        var exitItem = new WinForms.ToolStripMenuItem("Exit");
        exitItem.Click += (_, _) => Dispatcher.BeginInvoke(new Action(ExitFromTray));
        menu.Items.Add(exitItem);

        _tray.ContextMenuStrip = menu;

        _tray.DoubleClick += (_, _) => Dispatcher.BeginInvoke(new Action(ShowFromTray));

        // Window events
        StateChanged += (_, _) =>
        {
            if (_minimizeToTray && WindowState == WindowState.Minimized)
            {
                Hide();
            }
        };

        Closing += (_, e) =>
        {
            if (_exitRequested) return;
            if (_minimizeToTray)
            {
                e.Cancel = true;
                Hide();
            }
        };
    }

    private void ShowFromTray()
    {
        Show();
        if (WindowState == WindowState.Minimized)
            WindowState = WindowState.Normal;
        Activate();
        Topmost = true;   // nudge to front
        Topmost = false;
        Focus();
    }

    private void ExitFromTray()
    {
        _exitRequested = true;
        Close();
    }

    private void TraySettingChanged(object sender, RoutedEventArgs e)
    {
        _minimizeToTray = MinimizeToTrayCheck.IsChecked == true;
    }

    private void ToggleStartStop()
    {
        if (_engine == null)
        {
            _stopping = false;
            var settings = ReadSettingsFromUI();
            _engine = new PanEngine(settings);

            _engine.OnSnapshot = snapshot =>
            {
                if (_stopping) return;

                lock (_snapshotLock)
                {
                    _latestSnapshot = snapshot;
                }

                QueueUiUpdate();
            };

            _engine.Start();
            StartStopButton.Content = "Stop";
            RunStatusText.Text = "Running";
            ShowTrayToast("AudioPanUI", "Panning ON");
        }
        else
        {
            _stopping = true;
            _engine.Stop();
            _engine = null;

            _rows.Clear();
            _rowsByPid.Clear();
            StartStopButton.Content = "Start";
            RunStatusText.Text = "Stopped";
            ShowTrayToast("AudioPanUI", "Panning OFF — centered");
        }
    }

    private void RecenterNow()
    {
        try { _engine?.RecenterNow(); }
        catch { }
    }


    private void StartStop_Click(object sender, RoutedEventArgs e)
    {
        ToggleStartStop();
    }

    private void AnySettingChanged(object sender, EventArgs e)
    {
        if (!_isLoaded) return;

        RefreshLabels();
        if (_engine != null)
            _engine.UpdateSettings(ReadSettingsFromUI());
    }

    private void AnySettingChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_isLoaded) return;

        ApplyModeDefaults();
        RefreshLabels();
        if (_engine != null)
            _engine.UpdateSettings(ReadSettingsFromUI());
    }

    private void ApplyModeDefaults()
    {
        var mode = GetMode();

        if (mode == OutputMode.Headphones)
        {
            if (WidthSlider.Value > 0.999) WidthSlider.Value = 0.92;
            if (CrossfeedSlider.Value < 0.01) CrossfeedSlider.Value = 0.18;
            if (IntensitySlider.Value < 1.2) IntensitySlider.Value = 1.10;
        }
        else
        {
            WidthSlider.Value = 1.00;
            CrossfeedSlider.Value = 0.00;
            if (IntensitySlider.Value > 1.10) IntensitySlider.Value = 1.35;
        }
    }

    private void RefreshLabels()
    {
        IntensityValue.Text = IntensitySlider.Value.ToString("0.00");
        WidthValue.Text = WidthSlider.Value.ToString("0.00");
        CrossfeedValue.Text = CrossfeedSlider.Value.ToString("0.00");
        SmoothValue.Text = SmoothSlider.Value.ToString("0.00");
    }

    // Makes the top end feel noticeably snappier without changing behavior in the lower range.
    // We keep the slider value as the displayed value (0.05..1.0), but apply a non-linear boost
    // only in the last ~10% so it ramps to 1.0 more aggressively.
    private static float MapSmooth(double sliderValue)
    {
        // Safety clamp.
        if (sliderValue <= 0.0) return 0.0f;
        if (sliderValue >= 1.0) return 1.0f;

        const double knee = 0.90;
        if (sliderValue <= knee)
            return (float)sliderValue;

        // Remap (knee..1) => (0..1), then ease-out (sqrt) so it accelerates toward 1.0.
        double t = (sliderValue - knee) / (1.0 - knee);
        double eased = Math.Sqrt(t);
        return (float)(knee + (1.0 - knee) * eased);
    }

    private OutputMode GetMode()
    {
        var item = OutputModeCombo.SelectedItem as ComboBoxItem;
        var text = item?.Content?.ToString() ?? "Speakers";
        return text.Contains("Speaker", StringComparison.OrdinalIgnoreCase) ? OutputMode.Speakers : OutputMode.Headphones;
    }

    private PanSettings ReadSettingsFromUI()
    {
        int tick = 33;
        int.TryParse(TickMsBox.Text?.Trim(), out tick);
        if (tick < 10) tick = 10;
        if (tick > 100) tick = 100;

        return new PanSettings
        {
            Mode = GetMode(),
            TickMs = tick,
            Smooth = MapSmooth(SmoothSlider.Value),
            Deadband = 0.002f,
            Width = (float)WidthSlider.Value,
            Crossfeed = (float)CrossfeedSlider.Value,
            Intensity = (float)IntensitySlider.Value,
            GlobalAcrossMonitors = GlobalMonitorsCheck.IsChecked == true
        };
    }

    protected override void OnClosed(EventArgs e)
    {
        // Unregister global hotkeys
        try
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            if (hwnd != IntPtr.Zero)
            {
                UnregisterHotKey(hwnd, HOTKEY_ID_TOGGLE);            }
            if (_hwndSource != null)
            {
                _hwndSource.RemoveHook(WndProc);
                _hwndSource = null;
            }
        }
        catch { }

        if (_engine != null)
        {
            _stopping = true;
            _engine.Stop(); // includes recenter
            _engine = null;
        }

        try
        {
            if (_tray != null)
            {
                _tray.Visible = false;
                _tray.Dispose();
                _tray = null;
            }
        }
        catch { }

        base.OnClosed(e);
    }

    private void PanToggle_Checked(object sender, RoutedEventArgs e)
    {
        if (!_isLoaded) return;
        if (_engine == null) return;
        if (sender is not CheckBox cb) return;
        if (cb.DataContext is not SessionRow row) return;

        _panEnabledByPid[row.Pid] = true;
        _engine.SetPidPanEnabled(row.Pid, true);
    }

    private void PanToggle_Unchecked(object sender, RoutedEventArgs e)
    {
        if (!_isLoaded) return;
        if (_engine == null) return;
        if (sender is not CheckBox cb) return;
        if (cb.DataContext is not SessionRow row) return;

        _panEnabledByPid[row.Pid] = false;
        _engine.SetPidPanEnabled(row.Pid, false);
    }
}